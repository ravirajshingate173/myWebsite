## ⭐ Portfolio Website ⭐

Designed and developed a personal portfolio website to showcase my skills, experience, and projects. The website features a responsive layout, modern design, and 
interactive features to engage visitors.

## 📌 **Live Site URL:** <a href="https://indra-shekhar.netlify.app">**Visit Now** 🚀</a>

<br>

## 📌 Tech Stack

[![HTML](https://img.shields.io/badge/html5%20-%23E34F26.svg?&style=for-the-badge&logo=html5&logoColor=white)](https://github.com/Indra-S)&nbsp;
[![CSS](https://img.shields.io/badge/css3%20-%231572B6.svg?&style=for-the-badge&logo=css3&logoColor=white)](https://github.com/Indra-S)&nbsp; 
<br>

## 📬 Connect With Me

- **LinkedIn** - [Indra Shekhar](https://www.linkedin.com/in/indra-shekhar/)
- **Twitter** - [@Indra684](https://twitter.com/Indra684)

## 📌 Acknowledgments

- Course Instructor - [Love Babbar-CodeHelp](https://www.linkedin.com/in/love-babbar-38ab2887/)
- Icons Used For Tech Stack Section - [https://img.shields.io](https://img.shields.io)
